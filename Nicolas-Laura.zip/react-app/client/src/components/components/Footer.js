import React from 'react';
import './Footer.css';

export default function Footer() {
  return (
    <div className='footer-container'>

      <small class='website-rights'>Nicolas Ramos - Laura Callejo © 2022</small>



    </div>

  );
}

